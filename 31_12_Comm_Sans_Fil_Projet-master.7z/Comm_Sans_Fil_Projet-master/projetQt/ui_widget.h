/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QPushButton *connect;
    QTextEdit *Affichage;
    QPushButton *pushButton;
    QLabel *label;
    QPushButton *formater;
    QPushButton *btn_valider_infos;
    QLineEdit *Nom;
    QLineEdit *Prenom;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *estConnecte;
    QLabel *label_5;
    QLineEdit *credit;
    QPushButton *incrementer;
    QPushButton *decrementer;
    QLabel *val_Incremente;
    QLabel *barre;
    QLabel *barre_2;
    QLabel *label_2;
    QLabel *label_6;
    QLabel *label_Error;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(600, 600);
        Widget->setStyleSheet(QString::fromUtf8("background-color:rgb(193, 215, 255)"));
        connect = new QPushButton(Widget);
        connect->setObjectName(QString::fromUtf8("connect"));
        connect->setGeometry(QRect(340, 540, 170, 30));
        QFont font;
        font.setPointSize(16);
        connect->setFont(font);
        connect->setCursor(QCursor(Qt::PointingHandCursor));
        connect->setMouseTracking(true);
        connect->setStyleSheet(QString::fromUtf8("border: 1px solid black;\n"
"background-color:green;\n"
"color:white;"));
        Affichage = new QTextEdit(Widget);
        Affichage->setObjectName(QString::fromUtf8("Affichage"));
        Affichage->setGeometry(QRect(330, 460, 211, 51));
        Affichage->setStyleSheet(QString::fromUtf8("background-color:white;"));
        pushButton = new QPushButton(Widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(70, 540, 170, 30));
        pushButton->setFont(font);
        pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton->setMouseTracking(true);
        pushButton->setStyleSheet(QString::fromUtf8("background-color:rgb(255, 49, 49);\n"
"color:white;\n"
"border: 1px solid black;"));
        label = new QLabel(Widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(150, 20, 311, 51));
        QFont font1;
        font1.setPointSize(19);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        formater = new QPushButton(Widget);
        formater->setObjectName(QString::fromUtf8("formater"));
        formater->setGeometry(QRect(350, 360, 170, 30));
        formater->setFont(font);
        formater->setCursor(QCursor(Qt::PointingHandCursor));
        formater->setMouseTracking(true);
        formater->setStyleSheet(QString::fromUtf8("border: 1px solid black;\n"
"background-color:orange;\n"
"color:white;"));
        btn_valider_infos = new QPushButton(Widget);
        btn_valider_infos->setObjectName(QString::fromUtf8("btn_valider_infos"));
        btn_valider_infos->setGeometry(QRect(60, 360, 170, 30));
        btn_valider_infos->setFont(font);
        btn_valider_infos->setCursor(QCursor(Qt::PointingHandCursor));
        btn_valider_infos->setMouseTracking(true);
        btn_valider_infos->setStyleSheet(QString::fromUtf8("border: 1px solid black;\n"
"background-color:green;\n"
"color:white;"));
        Nom = new QLineEdit(Widget);
        Nom->setObjectName(QString::fromUtf8("Nom"));
        Nom->setGeometry(QRect(150, 130, 113, 20));
        Nom->setStyleSheet(QString::fromUtf8("background-color:white;"));
        Prenom = new QLineEdit(Widget);
        Prenom->setObjectName(QString::fromUtf8("Prenom"));
        Prenom->setGeometry(QRect(150, 180, 113, 20));
        Prenom->setStyleSheet(QString::fromUtf8("background-color:white;"));
        label_3 = new QLabel(Widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(56, 130, 81, 20));
        label_3->setFont(font);
        label_4 = new QLabel(Widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(56, 180, 81, 20));
        label_4->setFont(font);
        estConnecte = new QPushButton(Widget);
        estConnecte->setObjectName(QString::fromUtf8("estConnecte"));
        estConnecte->setGeometry(QRect(510, 20, 51, 51));
        estConnecte->setStyleSheet(QString::fromUtf8("border-radius:25px;\n"
"background-color:rgb(236, 236, 236);"));
        label_5 = new QLabel(Widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(56, 220, 61, 41));
        label_5->setFont(font);
        credit = new QLineEdit(Widget);
        credit->setObjectName(QString::fromUtf8("credit"));
        credit->setGeometry(QRect(150, 230, 113, 20));
        credit->setStyleSheet(QString::fromUtf8("background-color:white;"));
        incrementer = new QPushButton(Widget);
        incrementer->setObjectName(QString::fromUtf8("incrementer"));
        incrementer->setGeometry(QRect(480, 220, 51, 51));
        QFont font2;
        font2.setPointSize(35);
        incrementer->setFont(font2);
        incrementer->setCursor(QCursor(Qt::PointingHandCursor));
        incrementer->setMouseTracking(true);
        incrementer->setStyleSheet(QString::fromUtf8("border-radius:25px;\n"
"background-color:green;\n"
"color:white;"));
        decrementer = new QPushButton(Widget);
        decrementer->setObjectName(QString::fromUtf8("decrementer"));
        decrementer->setGeometry(QRect(360, 220, 51, 51));
        decrementer->setFont(font2);
        decrementer->setCursor(QCursor(Qt::PointingHandCursor));
        decrementer->setMouseTracking(true);
        decrementer->setStyleSheet(QString::fromUtf8("border-radius:25px;\n"
"background-color:red;\n"
"color:white;"));
        val_Incremente = new QLabel(Widget);
        val_Incremente->setObjectName(QString::fromUtf8("val_Incremente"));
        val_Incremente->setGeometry(QRect(440, 170, 61, 41));
        QFont font3;
        font3.setPointSize(22);
        val_Incremente->setFont(font3);
        barre = new QLabel(Widget);
        barre->setObjectName(QString::fromUtf8("barre"));
        barre->setGeometry(QRect(40, 410, 511, 41));
        barre_2 = new QLabel(Widget);
        barre_2->setObjectName(QString::fromUtf8("barre_2"));
        barre_2->setGeometry(QRect(50, 70, 511, 41));
        label_2 = new QLabel(Widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 440, 281, 81));
        QFont font4;
        font4.setPointSize(12);
        label_2->setFont(font4);
        label_2->setAcceptDrops(false);
        label_2->setWordWrap(true);
        label_6 = new QLabel(Widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(350, 120, 171, 41));
        label_6->setFont(font);
        label_Error = new QLabel(Widget);
        label_Error->setObjectName(QString::fromUtf8("label_Error"));
        label_Error->setGeometry(QRect(50, 300, 501, 21));
        label_Error->setFont(font);
        label_Error->setStyleSheet(QString::fromUtf8("color:red;"));
        label_Error->setAlignment(Qt::AlignCenter);
        connect->raise();
        pushButton->raise();
        label->raise();
        formater->raise();
        btn_valider_infos->raise();
        Nom->raise();
        Prenom->raise();
        label_3->raise();
        label_4->raise();
        label_5->raise();
        credit->raise();
        incrementer->raise();
        decrementer->raise();
        val_Incremente->raise();
        barre->raise();
        barre_2->raise();
        estConnecte->raise();
        label_2->raise();
        Affichage->raise();
        label_6->raise();
        label_Error->raise();

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
        connect->setText(QCoreApplication::translate("Widget", "Connect", nullptr));
        pushButton->setText(QCoreApplication::translate("Widget", "Quitter", nullptr));
        label->setText(QCoreApplication::translate("Widget", "CONNECTEUR DE CARTE", nullptr));
        formater->setText(QCoreApplication::translate("Widget", "Formater", nullptr));
        btn_valider_infos->setText(QCoreApplication::translate("Widget", "Valider", nullptr));
        label_3->setText(QCoreApplication::translate("Widget", "Nom :", nullptr));
        label_4->setText(QCoreApplication::translate("Widget", "Pr\303\251nom :", nullptr));
        estConnecte->setText(QString());
        label_5->setText(QCoreApplication::translate("Widget", "Cr\303\251dit : ", nullptr));
        incrementer->setText(QCoreApplication::translate("Widget", "+", nullptr));
        decrementer->setText(QCoreApplication::translate("Widget", "-", nullptr));
        val_Incremente->setText(QCoreApplication::translate("Widget", "0", nullptr));
        barre->setText(QCoreApplication::translate("Widget", "____________________________________________________________________________________", nullptr));
        barre_2->setText(QCoreApplication::translate("Widget", "____________________________________________________________________________________", nullptr));
        label_2->setText(QCoreApplication::translate("Widget", "Informations sur le lecteur et la carte :", nullptr));
        label_6->setText(QCoreApplication::translate("Widget", "Cr\303\251diter la carte :", nullptr));
        label_Error->setText(QCoreApplication::translate("Widget", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
