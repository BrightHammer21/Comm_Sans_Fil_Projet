//#pragma comment(lib, "ODALID.lib")
#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QtGui>
#include "ODALID.h"
#include "mferror.h"

Widget::Widget(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    btn_cliquable(false);


    //--------------------Initialisation du timer et connection au slot
    qDebug()<<"INITIALISATION";
    carteConnectee=false;
    ui->formater->setEnabled(false);
    ui->formater->setStyleSheet("QPushButton{background-color:#AEAEAE; border:1px solid black;}");
    ui->btn_deconnecter->setStyleSheet("QPushButton{background-color:#E0E0E0;border:1px solid black;}");
    ui->btn_deconnecter->setEnabled(false);
    ui->label_Error->setHidden(true);


    timer = new QTimer(this);
    timer->setTimerType(Qt::CoarseTimer);

    connect(timer, SIGNAL(timout()), this, SLOT(identifier()));
}


Widget::~Widget()
{
    delete ui;
}

ReaderName MonLecteur;
char pszHost[] = "192.168.1.4";

//CONNNEXION AU LECTEUR
void Widget::on_connect_clicked()
{

    uint16_t status = 0;

    MonLecteur.Type = ReaderCDC;
    MonLecteur.device = 0;
    status = OpenCOM(&MonLecteur);



     if(status != 0)
     {
          qDebug() <<  GetErrorMessage(status);
     }
     else {
          LEDBuzzer(&MonLecteur, LED_GREEN_ON);
          ui->connect->setStyleSheet("QPushButton{background-color:#E0E0E0;border:1px solid black;}");
          ui->connect->setEnabled(false);
          ui->btn_deconnecter->setStyleSheet("QPushButton{background-color:red;border:1px solid black;color:white;}");
          ui->btn_deconnecter->setEnabled(true);
     }


     //VERSION
     char version[30];
     uint8_t serial[4];
     char stackReader[20];

     status = Version(&MonLecteur, version, serial, stackReader);

     ui->Affichage->setText(QString(version));

     ui->Affichage->update();

     //AFFICHAGE DU STATUT CLE
     uint16_t etat =0;

     etat = Mf_Classic_LoadKey(&MonLecteur, Auth_KeyA, key_A, 2);
     qDebug() << "Etat : " << etat;


     etat = Mf_Classic_LoadKey(&MonLecteur, Auth_KeyB, key_B, 2);
     qDebug() << "Etat : " << etat;


     etat = Mf_Classic_LoadKey(&MonLecteur, Auth_KeyA, key_A2, 3);
     qDebug() << "Etat : " << etat;

     etat = Mf_Classic_LoadKey(&MonLecteur, Auth_KeyB, key_B2, 3);
     qDebug() << "Etat : " << etat;


     etat = Mf_Classic_LoadKey(&MonLecteur, Auth_KeyA, key_F, 0);
     qDebug() << "Etat : " << etat;

     etat = Mf_Classic_LoadKey(&MonLecteur, Auth_KeyB, key_F, 0);
     qDebug() << "Etat : " << etat;

     ui->connect->setEnabled(false);
     timer->start(1000);


     identifier();

}

//BOUTON QUITTER
void Widget::on_pushButton_clicked()
{
     int16_t status = 0;
     RF_Power_Control(&MonLecteur, FALSE, 0);
     status = LEDBuzzer(&MonLecteur, LED_OFF);
     status = CloseCOM(&MonLecteur);

     qApp->quit();

}


void Widget::identifier()
{
    uint16_t status;

    uint8_t atq[2];  //réponse à la requête
    uint8_t sak[1];  //select acknowledge
    uint8_t uid[12]; //identifiant unique
    uint16_t uid_len = 12;


    qDebug() << "Identification de la carte : ";

    //On regarde si la carte est toujours sur le lecteur
    status = ISO14443_3_A_PollCard(&MonLecteur, atq, sak, uid, &uid_len);


    if(carteConnectee) //On déactive tout si la carte n'est pas présente
    {

        ui->estConnecte->setStyleSheet("QPushButton{background-color:orange;border-radius:25px;}");

        //Si la carte n'est plus sur le lecteur
        if(status!=0)
        {
            carteConnectee = false;
            LEDBuzzer(&MonLecteur, LED_GREEN_OFF);
            LEDBuzzer(&MonLecteur, LED_YELLOW_ON); //On affiche un voyant jaune pour signaler qu'il manque la carte
            qDebug() << "Aucune carte détectée.";
            btn_cliquable(false);

            ui->Affichage->setText(ui->Affichage->toPlainText()+"\nAucune carte détectée");
            ui->estConnecte->setStyleSheet("QPushButton{background-color:red;border-radius:25px;}");
        }

    }
    else //si carte connectée, mise à jour
    {
        //activer les champs RF pour un temps indéterminé
        RF_Power_Control(&MonLecteur, TRUE, 0);

        if(status!= 0)
        {
            ui->estConnecte->setStyleSheet("QPushButton{background-color:orange;border-radius:25px;}");
            ui->Affichage->setText(ui->Affichage->toPlainText()+"\nCarte Mifare non connectée");
            ui->Affichage->update();

            ui->connect->setEnabled(true);
            ui->connect->setStyleSheet("QPushButton{background-color:green;border:1px solid black;color:white;}");
            ui->btn_deconnecter->setEnabled(false);
            ui->btn_deconnecter->setStyleSheet("QPushButton{background-color:#E0E0E0;border:1px solid black;}");
        }
        else
        {
            ui->estConnecte->setStyleSheet("QPushButton{background-color:green;border-radius:25px;}");

            carteConnectee = true;

            LEDBuzzer(&MonLecteur, LED_GREEN_ON);
            btn_cliquable(true);

            qDebug() << "UID trouvé : ";
            for(int i=0; i<uid_len; i++)
            {
                qDebug() << uid[i];
            }

            qDebug()<< "ATQ = " << atq[1] << atq[0] << "\nSAK = " << sak[0]<<"\n";

            ui->Affichage->setText(ui->Affichage->toPlainText()+"\nCarte Mifare connectée");
            ui->Affichage->update();

            lectureDonneesCartes();
        }
    }

}

void Widget::lectureDonneesCartes()
{
    int16_t status;
    uint32_t nom[16] = {'-'};
    uint32_t prenom[16] = {'-'};
    uint32_t monCredit=0;


    status = Mf_Classic_Read_Block(&MonLecteur, TRUE, 10, (uint8_t*)nom, TRUE, 2);
    if(status!=0)
    {
        qDebug() << "Erreur : " << GetErrorMessage(status);
    }

    qDebug() << "nomAvant : " << (uint8_t*)nom;
    qDebug() << "nomAvant : " << (uint8_t*)prenom;

    status = Mf_Classic_Read_Block(&MonLecteur, TRUE, 9,  (uint8_t*)prenom, TRUE, 2);
    if(status!=0)
    {
        qDebug() << "Erreur :" << GetErrorMessage(status);
    }


    //affichage dans la fenetre
    ui->Nom->setText(QString((const char*)nom));
    ui->Prenom->setText(QString((const char*)prenom));

    //lecture du crédit
    status = Mf_Classic_Read_Value(&MonLecteur, TRUE, 14, &monCredit, TRUE, 3);
    ui->credit->setText(QString("%1").arg(monCredit));

}

void Widget::btn_cliquable(bool boolean)
{

     ui->incrementer->setEnabled(boolean);
     ui->decrementer->setEnabled(boolean);
     ui->btn_valider_infos->setEnabled(boolean);

     if(boolean == false)
     {
          ui->incrementer->setStyleSheet("QPushButton{background-color:#AEAEAE;border-radius:25px;}");
          ui->decrementer->setStyleSheet("QPushButton{background-color:#AEAEAE;border-radius:25px;}");
          ui->btn_valider_infos->setStyleSheet("QPushButton{background-color:#AEAEAE;border:1px solid black;}");


     }
     else
     {
         ui->incrementer->setStyleSheet("QPushButton{background-color:green;border-radius:25px;color:white;}");
         ui->decrementer->setStyleSheet("QPushButton{background-color:red;border-radius:25px;color:white;border: 1px solid black;}");
         ui->btn_valider_infos->setStyleSheet("QPushButton{background-color:green;border:1px solid black;color:white;}");
     }
}

//////////////////////////////////////////////////////CHANGER NOM PRENOM CREDIT
void Widget::on_btn_valider_infos_clicked()
{
    int16_t status = 0;

    //Nom et prénom
    unsigned char nom[16];
    unsigned char prenom[16];


    int ancien_nom = ui->Nom->text().length();
    int ancien_prenom = ui->Prenom->text().length();
    int monCredit = ui->credit->text().toInt();

    for(int i=0; i<16;i++)
    {
        nom[i]=ui->Nom->text().toStdString()[i];
        prenom[i]=ui->Prenom->text().toStdString()[i];

        if(i>=ancien_nom)
        {
            nom[i]= '\0';

        }
        if(i>=ancien_prenom)
        {
            prenom[i]='\0';
        }
    }
    //vérification accès aux secteurs idéntité et secteur en écriture
    unsigned char identite[]="Identité";
    unsigned char compteur[]="Compteur";

    status = Mf_Classic_Write_Block(&MonLecteur, TRUE,8,identite, Auth_KeyB,2);

    if(status!=0)
    {
        qDebug()<<"Identification : "<<GetErrorMessage(status);
    }
    status = Mf_Classic_Write_Block(&MonLecteur, TRUE,14,compteur, Auth_KeyB,3);
    if(status!=0)
    {
        qDebug()<<"Compteur : "<<GetErrorMessage(status);
    }

    //idem pour nom et prénom
    status = Mf_Classic_Write_Block(&MonLecteur, TRUE,10,nom, Auth_KeyB,2);
    if(status!=0)
    {
        qDebug()<<"Nom : "<<GetErrorMessage(status);
    }
     status = Mf_Classic_Write_Block(&MonLecteur, TRUE,9,prenom, Auth_KeyB,2);
     if(status!=0)
     {
         qDebug()<<"Prénom : "<<GetErrorMessage(status);
     }

     //Partie compteur
     status = Mf_Classic_Write_Value(&MonLecteur, TRUE,14,monCredit, Auth_KeyB,3);
     if(status!=0)
     {
         qDebug()<<"Compteur : "<<GetErrorMessage(status);
     }
     status = Mf_Classic_Write_Value(&MonLecteur, TRUE,13,0, Auth_KeyB,3);
     if(status!=0)
     {
         qDebug()<<"Backup : "<<GetErrorMessage(status);
     }

     lectureDonneesCartes();


    ui->formater->setEnabled(true);
    ui->formater->setStyleSheet("QPushButton{background-color:orange;border-radius:25px; border: 1px solid black;;}");
    qDebug()<<"Données modifiées";

}

void Widget::on_formater_clicked()
{
    int16_t status = 0;

    qDebug() << "nom : " << this->sauvegarde_nom;
    qDebug() << "nom : " << this->sauvegarde_prenom;



    status = Mf_Classic_Write_Block(&MonLecteur, TRUE, 9, (uint8_t*)"Vincent", FALSE, 2);
    if(status!=0)
    {
        qDebug()<<GetErrorMessage(status);
        ui->label_Error->setText(GetErrorMessage(status));
    }

    status = Mf_Classic_Write_Block(&MonLecteur, TRUE,10, (uint8_t*)"Thivent", FALSE, 2);
    if(status!=0)
    {
        qDebug()<<GetErrorMessage(status);
    }

    unsigned char compteur[]="Porte Monnaie";

    status = Mf_Classic_Write_Block(&MonLecteur, TRUE,14,compteur, Auth_KeyB,3);
    if(status!=0)
     {
         qDebug()<<"Ecriture " <<GetErrorMessage(status);
     }

   status = Mf_Classic_Write_Value(&MonLecteur, TRUE,14,10, Auth_KeyB,3);
   status = Mf_Classic_Write_Value(&MonLecteur, TRUE,13,0, Auth_KeyB,3);

    lectureDonneesCartes();

    qDebug() << "Carte formatée";

}


void Widget::on_decrementer_clicked()
{
    int16_t status = 0;
    uint32_t credit = ui->credit->text().toInt();
    int valeur = 1;
    qDebug()<<"On décrémente";

    status = Mf_Classic_Read_Value(&MonLecteur, TRUE, 14,(uint32_t*) &credit,Auth_KeyA,3);

    if(credit ==0 || credit-valeur > credit)
    {
        ui->decrementer->setEnabled(false);
        ui->decrementer->setStyleSheet("QPushButton{background-color:#AEAEAE;border-radius:25px;}");

        qDebug()<<"Décrémentation impossible";
        ui->label_Error->setText("Vous ne pouvez plus décrémenter");
    }
    else
    {

        ui->decrementer->setStyleSheet("QPushButton{background-color:red;border-radius:25px;color:white;border: 1px solid black;}");
        status = Mf_Classic_Decrement_Value(&MonLecteur, TRUE, 14, valeur, 13, Auth_KeyA,3);
        if(status!=0)
        {
           qDebug()<<"Decrement error : "<<GetErrorMessage(status);
        }

        status = Mf_Classic_Restore_Value(&MonLecteur, TRUE, 13, 14, Auth_KeyA,3);
        if(status!=0)
        {
           qDebug()<<"Restore error : "<<GetErrorMessage(status);
        }

         status = Mf_Classic_Read_Value(&MonLecteur, TRUE, 14,(uint32_t*) &credit,Auth_KeyA,3);

        ui->credit->setText(QString("%1").arg(credit));

   }

}

void Widget::on_incrementer_clicked()
{
    int16_t status = 0;
    uint32_t credit = ui->credit->text().toInt();
    int valeur = 1;

    qDebug()<<"On incrémente";

    status = Mf_Classic_Increment_Value(&MonLecteur, TRUE, 14, valeur, 13, Auth_KeyB,3);

    if(status!=0)
    {
       qDebug()<<"Increment error : "<<GetErrorMessage(status);
       ui->label_Error->setText(GetErrorMessage(status));
    }

    status = Mf_Classic_Restore_Value(&MonLecteur, TRUE, 13, 14, Auth_KeyB,3);
    if(status!=0)
    {
       qDebug()<<"Restore error : "<<GetErrorMessage(status);
         ui->label_Error->setText(GetErrorMessage(status));
    }

    status = Mf_Classic_Read_Value(&MonLecteur, TRUE, 14, (uint32_t*)&credit,Auth_KeyA,3);

    if(credit>0)
    {
        ui->decrementer->setStyleSheet("QPushButton{background-color:red;border-radius:25px;color:white;border: 1px solid black;}");
        ui->decrementer->setEnabled(true);
    }

    ui->credit->setText(QString("%1").arg(credit));



}

void Widget::on_btn_deconnecter_clicked()
{
    int16_t status = 0;
    RF_Power_Control(&MonLecteur, FALSE, 0);
    status = LEDBuzzer(&MonLecteur, LED_OFF);
    status = CloseCOM(&MonLecteur);

    ui->estConnecte->setStyleSheet("QPushButton{background-color:orange;border-radius:25px;}");
    ui->Affichage->setText("");
    ui->Affichage->update();

    ui->btn_deconnecter->setStyleSheet("QPushButton{background-color:#E0E0E0;border:1px solid black;}");

    ui->connect->setEnabled(true);
    ui->connect->setStyleSheet("QPushButton{background-color:green;border:1px solid black;color:white;}");

    ui->Nom->setText("");
    ui->Prenom->setText("");
    ui->credit->setText("");

    carteConnectee=false;
}
